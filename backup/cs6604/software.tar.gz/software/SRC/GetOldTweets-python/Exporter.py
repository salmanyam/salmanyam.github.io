# -*- coding: utf-8 -*-
import csv
import re
import string
from dateutil.parser import parse
import sys,getopt,datetime,codecs
from datetime import datetime as dt

if sys.version_info[0] < 3:
    import got
else:
    import got3 as got

def main(argv):
	outputFileName = "twitter_data.csv"
	outputFile = codecs.open(outputFileName, "w+", "utf-8")	
	outputFile.write('project id;project name;username;date;retweets;favorites;project_url;geo;mentions;hashtags;id;permalink')
	
	project_file = open("crowdfunding.data.10.17.csv")
	project_reader = csv.reader(project_file)

	def receiveBuffer(tweets, project_id, project_name):
		#print('More %d saved on file...\n' % len(tweets))
		for t in tweets:
			print(t.text)
			try:
				outputFile.write(('\n%s,%s,%s,%s,%d,%d,"%s",%s,%s,%s,"%s",%s' % (project_id, project_name,t.username, t.date.strftime("%Y-%m-%d %H:%M"), t.retweets, t.favorites, t.text, t.geo, t.mentions, t.hashtags, t.id, t.permalink)))
				outputFile.flush();
			except UnicodeDecodeError:
				continue
        i = 0
	for row in project_reader:
		#print(row[0])
		if row[2] is None:
			continue
	        
                start_date = row[15]
                end_date = row[16]

                if start_date is None or bool(start_date) == False:
                        continue
             
                if end_date is None or bool(end_date) == False:
                        continue

                if i == 0:
                        i += 1
                        continue
                start_date = dt.strptime(start_date, '%m/%d/%Y')
                end_date = dt.strptime(end_date, '%m/%d/%Y')
                #print(start_date.strftime('%Y-%m-%d'),
                 #       end_date.strftime('%Y-%m-%d'))
                
                start = start_date.strftime('%Y-%m-%d')
                end = end_date.strftime('%Y-%m-%d')

                i += 1

		p_name = row[1]
		row[1].translate(None, string.punctuation)
		if len(row[1].split()) <=2:
			if row[2] != None:
				row[1] += row[2].rsplit('/', 1)[-1]
		row[1] += " kickstarter"
		#tweetCriteria.querySearch = row[1]
		
		if len(row[1].split()) <=3:
			continue
			
		tweetCriteria = got.manager.TweetCriteria().setQuerySearch(row[1]).setSince(start).setUntil(end)
		try:
			got.manager.TweetManager.getTweets(tweetCriteria, row[0], p_name, receiveBuffer)
		except:
			continue

        print('total', i)
	outputFile.close()
	print('Done. Output file generated "%s".' % outputFileName)

if __name__ == '__main__':
	main(sys.argv[1:])
