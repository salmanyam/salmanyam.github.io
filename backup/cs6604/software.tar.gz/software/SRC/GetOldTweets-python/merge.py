# -*- coding: utf-8 -*-
import csv
import re
import string
from urlunshort import resolve
from urlunshort import is_shortened
import urltools

import sys,getopt,datetime,codecs

def main(argv):
	fout = open("project_twitter_data.csv", "a")
	#fout.write('project_id, project_name, username, date, retweets, favorites, text, geo, mentions, hashtags, id, permalink\n')
	
	f = open("output4.csv")
	f.next()
	
	for line in f:
		fout.write(line)
	f.close()
	

	fout.close()

if __name__ == '__main__':
	main(sys.argv[1:])
