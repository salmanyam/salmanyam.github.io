How to use the GetOldTweets-python software package to get old tweets
=====================================================================
	1. The Exporter.py is modified to feed the keywords and date range from each of the crowdfunding projects.[no need to do anything here]
	2. Copy the crowdfunding project dataset in the GetOldTweets-python directory
	3. Run python Exporter.py

It will automatically download all the relevant tweets and store in twitter_data.csv file

For each of the following python notebooks, please copy the crowdfunding project dataset and the twitter dataset in the notebook director. The datasets are availabe on http://people.cs.vt.edu/ahmedms/cs6604.html

What is analyze_crowdfunding_projects.ipynb python notebook?
============================================================
This notebook analyzes the crowdfunding project dataset to get the summary statistics of the crowdfunding projects. The notebook has been documented for each step.

What are analyze_crowdfunding_projects_cleaned.ipynb and analyze_crowdfunding_projects-cleaned2.ipynb python notebooks?
===========================================================================================================
This two notebooks analyze the crowdfunding projects after cleaning and cross relevancy checking with the twitter dataset. The notebooks have been documented for each step.

What is Approximation_prediction_using_simple_model.ipynb python notebook?
==========================================================================
This notebook reads the crowdfunding projects and filters out the projects that do not have any tweets. Then, it calculate the beta values for each project using the twitter data. Then it calculates the acutal infections over time and fits a curve to get the beta from the actual infection curve. Then it calculates the average beta value for all successful or failed projects. Using the beta value, it calculates the actual and predicted infections over time.

What are Avg_exposure_and_prediction_failed_projects.ipynb and Avg_exposure_and_prediction_successful_projects.ipynb
====================================================================
Each of this two notebooks is responsible for calculating the average exposure curve for all the successful projects or all the failed projects. To do this, the notebook first reads the crowdfunding projects and filters out the projects that do not have any tweets. Then it calculates the exposure curves for each of the successful projects or each of the failed projects. Then it averages the exposure curves to get an average exposure for the successful projects or the failed projects. Then it fits a exponentially decreasing curve to get the decay rate. Using the decay rate, it approximates the infections over time.

What is data_process.ipynb?
==========================
This notebook contains the basic utilites about how to group, how create new panda data frame, how to discard columns in panda dataframe, etc.